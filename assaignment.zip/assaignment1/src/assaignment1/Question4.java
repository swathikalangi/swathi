package assaignment1;
import java.util.Scanner;
public class Question4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the cost price : ");
		int costPrice=scanner.nextInt();
		System.out.println("Enter the selling price :");
		int sellingPrice=scanner.nextInt();
		int profit,loss;
		if(sellingPrice > costPrice)
		{
			profit=sellingPrice - costPrice;
			System.out.println("Profit : "+profit);
		}
		else if(sellingPrice < costPrice)
		{
			loss=costPrice-sellingPrice;
			System.out.println("loss : "+loss);
		}
		else if(sellingPrice==costPrice)
		{
			System.out.println("neither loss nor profit");
		}
	}




	}


