package assaignment2;

public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 for(int i=3;i>=1;i--)
	        {
			for(int k=3;k>i;k--)
			{
				System.out.print(" ");
			}
			for(int j=1;j<=i;j++)
			{
				System.out.print(j+" ");
			}
			for(int l=i-1;l>=1;l--)
			{
				System.out.print(l+" ");
			}
			System.out.println();
		}

	}

}
