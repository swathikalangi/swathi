package assaignment2;

public class Question6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=3;i++)
		{
			for(int k=2;k>=i;k--)
			{
				System.out.print(" ");
			}
        for(int j=1;j<=i*2-1;j++)
        {
        	if(j==1||j==2*i-1)
        	{
         System.out.print(1);
        	}
        	else
        	{
        		System.out.print("*");
        	}
        }
        
        System.out.println();
		}
		for(int i=3;i>=1;i--)
		{
			for(int k=2;k>=i;k--)
			{
				System.out.print(" ");
			}
        for(int j=1;j<=i*2-1;j++)
        {
        	if(j==1||j==2*i-1)
        	{
         System.out.print(1);
        	}
        	else
        	{
        		System.out.print("*");
        	}
        }
        
        System.out.println();
		}


	}

}
